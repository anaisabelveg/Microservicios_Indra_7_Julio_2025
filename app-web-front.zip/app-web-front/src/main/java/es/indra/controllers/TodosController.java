package es.indra.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.indra.business.IGestionBS;
import es.indra.models.Producto;

@Controller
@RequestMapping("/todos")
public class TodosController {
	
	@Autowired
	private IGestionBS bs;
	
	@RequestMapping(method = RequestMethod.GET, value = "")
	public String inicio(Model model) {
		List<Producto> lista = bs.obtenerTodos();
		model.addAttribute("lista", lista);
		return "mostrarTodos";
	}

}
