package es.indra.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import es.indra.business.IValoracionesBS;

@Service
public class Consumidor {
	
	@Autowired
	private IValoracionesBS bs;
	
	@KafkaListener(topics = "indra-cluster")
	public void recibirComentario(String comentario) {
		System.out.println("Comentario recibido: " + comentario);
		bs.crearValoracion(comentario);
	}

}
