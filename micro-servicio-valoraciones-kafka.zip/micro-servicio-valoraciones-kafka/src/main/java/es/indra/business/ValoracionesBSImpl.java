package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.models.Valoracion;
import es.indra.persistence.ValoracionesDAO;

@Service
public class ValoracionesBSImpl implements IValoracionesBS{
	
	@Autowired
	private ValoracionesDAO dao;

	@Override
	public void crearValoracion(String mensaje) {
		dao.save(new Valoracion(mensaje));
		
	}

}
