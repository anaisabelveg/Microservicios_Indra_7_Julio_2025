package es.indra.business;

public interface IValoracionesBS {
	
	void crearValoracion(String mensaje);

}
