package es.indra.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "VALORACIONES")
public class Valoracion implements Serializable{
	
	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)  // incremental
	private Integer id;
	
	@Column(name = "MENSAJE")
	private String mensaje;
	
	public Valoracion() {
		// TODO Auto-generated constructor stub
	}

	public Valoracion(String mensaje) {
		super();
		this.mensaje = mensaje;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	@Override
	public String toString() {
		return "Valoracion [id=" + id + ", mensaje=" + mensaje + "]";
	}
	
}
