package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@Service  // Esto lo convierte en un bean de Spring
public class ProductosBSImpl implements IProductosBS{
	
	@Autowired
	private ProductosDAO dao;  // Inyeccion de dependencias DI

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(Long id) {
		return dao.findById(id).orElse(new Producto());
	}

}
